<div class="footer-section">
						<div class="container">
							<div class="footer-top">
								<p>copyrights &copy; 2020 @ Hotel Booking Management Sytem  </p>
							</div>
						
				</div>
			</div>