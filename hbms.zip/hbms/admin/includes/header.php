<div class="header-section">
            <!-- top_bg -->
                        <div class="top_bg">
                            
                                <div class="header_top">
                                    <div class="top_right">
                                        <ul>
                                            <li><a href="profile.php"><i class="fa fa-user"></i> My Profile</a></li>|
                                            <li><a href="change-password.php"><i class="fa fa-key"></i> Change Password</a></li>|
                                            <li><a href="logout.php"><i class="fa fa-power-off"></i> Logout</a></li>
                                        </ul>
                                    </div>
                                   
                                        <div class="clearfix"> </div>
                                </div>
                            
                        </div>
                    <div class="clearfix"></div>
                <!-- /top_bg -->
                </div>
                <div class="header_bg">
                        
                            <div class="header">
                                <div class="head-t">
                                    <div class="logo">
                                        <a href="dashboard.php" style="font-size: 20px;color: #9c27b0"><i class="fa fa-dashboard"></i> Hotel Booking Management System </a>
                                    </div>
                                        <!-- start header_right -->
                                    
                                <div class="clearfix"> </div>
                            </div>
                        </div>
                    
                </div>