<div>
         
                    <div class="clearfix"><br><br><br><br><br><br> </div>
            <div class="footer offbox">
                        <p style="font-family: cursive;">Copyrights © 2020 @ Hotel Booking Management System </p>
            </div>
        </div>