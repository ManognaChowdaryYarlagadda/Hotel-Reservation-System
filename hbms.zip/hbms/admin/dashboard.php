<?php
session_start();
error_reporting(0);
include('includes/dbconnection.php');
if (strlen($_SESSION['hbmsaid']==0)) {
  header('location:logout.php');
  } else{



  ?>
<!DOCTYPE HTML>
<html>
<head>
<title>Hotel Booking Management System | Dashboard</title>

<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.min.css" rel='stylesheet' type='text/css' />
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<!-- Graph CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- jQuery -->
<link href='//fonts.googleapis.com/css?family=Roboto:700,500,300,100italic,100,400' rel='stylesheet' type='text/css'/>
<link href='//fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<!-- lined-icons -->
<link rel="stylesheet" href="css/icon-font.min.css" type='text/css' />
<script src="js/amcharts.js"></script>	
<script src="js/serial.js"></script>	
<script src="js/light.js"></script>	
<!-- //lined-icons -->
<script src="js/jquery-1.10.2.min.js"></script>
   <!--pie-chart--->
<script src="js/pie-chart.js" type="text/javascript"></script>
 <script type="text/javascript">

        $(document).ready(function () {
            $('#demo-pie-1').pieChart({
                barColor: '#3bb2d0',
                trackColor: '#eee',
                lineCap: 'round',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-2').pieChart({
                barColor: '#fbb03b',
                trackColor: '#eee',
                lineCap: 'butt',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-3').pieChart({
                barColor: '#ed6498',
                trackColor: '#eee',
                lineCap: 'square',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

           
        });

    </script>
</head> 
<body>
   <div class="page-container">
   <!--/content-inner-->
	<div class="left-content">
	   <div class="inner-content">
		<!-- header-starts -->
			<?php include_once('includes/header.php');?>
					<!-- //header-ends -->
				
				<!--content-->
			<div class="content">
					
						<center class="bgcolorch"><h1 style="color:#fff; padding:20px;">WELCOME ADMIN</h1></center>
				<p><br>&nbsp;<br></p>
							<div class="col-md-12">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="content-top-1 box3d">
                                <h4 class="text-left text-uppercase" style="color: orange"><a href="new-booking.php"><b>New Booking</b></a></h4>
                                <div class="row vertical-center-box 
                                vertical-center-box-tablet">
                                <?php 
                        $sql2 ="SELECT * from  tblbooking where Status is null ";
$query2 = $dbh -> prepare($sql2);
$query2->execute();
$results2=$query2->fetchAll(PDO::FETCH_OBJ);
$totnewbooking=$query2->rowCount();
?>
                                    <div class="col-xs-3 mar-bot-15 text-left">
                                        <label class="label bg-green"></label>
                                    </div>
                                    <div class="col-xs-9 cus-gh-hd-pro">
                                        <h2 class="text-right no-margin"><?php echo htmlentities($totnewbooking);?></h2>
                                    </div>
                                </div>
                                <div class="progress progress-mini">
                                    <div style="width: 7%;" class="progress-bar bg-green"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" style="margin-bottom:1px;">
                            <div class="content-top-1 box3d">
                                <h4 class="text-left text-uppercase" style="color: red"><a href="approved-booking.php"><b>Approved Booking</b></a></h4>
                                <div class="row vertical-center-box vertical-center-box-tablet">
                                	<?php 
                        $sql2 ="SELECT * from  tblbooking where Status='Approved'";
$query2 = $dbh -> prepare($sql2);
$query2->execute();
$results2=$query2->fetchAll(PDO::FETCH_OBJ);
$totappbooking=$query2->rowCount();
?>
                                    <div class="text-left col-xs-3 mar-bot-15">
                                        <label class="label bg-red"></label>
                                    </div>
                                    <div class="col-xs-9 cus-gh-hd-pro">
                                        <h2 class="text-right no-margin"><?php echo htmlentities($totappbooking);?></h2>
                                    </div>
                                </div>
                                <div class="progress progress-mini">
                                    <div style="width: 8%;" class="progress-bar progress-bar-danger bg-red"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="content-top-1 box3d">
                                <h4 class="text-left text-uppercase" style="color: magenta"><a href="cancelled-booking.php"><b>Cancelled Booking</b></a></h4>
                                <div class="row vertical-center-box vertical-center-box-tablet">
                                	<?php 
                        $sql2 ="SELECT * from  tblbooking where Status='Cancelled'";
$query2 = $dbh -> prepare($sql2);
$query2->execute();
$results2=$query2->fetchAll(PDO::FETCH_OBJ);
$totcanbooking=$query2->rowCount();
?>
                                    <div class="text-left col-xs-3 mar-bot-15">
                                        <label class="label bg-blue"></label>
                                    </div>
                                    <div class="col-xs-9 cus-gh-hd-pro">
                                        <h2 class="text-right no-margin"><?php echo htmlentities($totcanbooking);?></h2>
                                    </div>
                                </div>
                                <div class="progress progress-mini">
                                    <div style="width: 5%;" class="progress-bar bg-blue"></div>
                                </div>
                            </div>
                        </div>
                      
                    </div>
                </div>
						<div class="col-md-12" style="padding-top: 20px">
                    <div class="row">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="content-top-1 box3d">
                                <h4 class="text-left text-uppercase" style="color: orange"><a href="reg-users.php"><b>Registered Users</b></a></h4>
                                <div class="row vertical-center-box vertical-center-box-tablet">
                                	<?php 
						$sql1 ="SELECT * from  tbluser";
$query1 = $dbh -> prepare($sql1);
$query1->execute();
$results1=$query1->fetchAll(PDO::FETCH_OBJ);
$totregusers=$query1->rowCount();
?>
                                    <div class="col-xs-3 mar-bot-15 text-left">
                                        <label class="label bg-green"></label>
                                    </div>
                                    <div class="col-xs-9 cus-gh-hd-pro">
                                        <h2 class="text-right no-margin"><?php echo htmlentities($totregusers);?></h2>
                                    </div>
                                </div>
                                <div class="progress progress-mini">
                                    <div style="width: 8%;" class="progress-bar bg-green"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" style="margin-bottom:1px;">
                            <div class="content-top-1 box3d">
                                <h4 class="text-left text-uppercase" style="color: red"><a href="read-enquiry.php"><b>Read Enquries</b></a></h4>
                                <div class="row vertical-center-box vertical-center-box-tablet">
                                	<?php 
						$sql1 ="SELECT * from  tblcontact where Isread='1'";
$query1 = $dbh -> prepare($sql1);
$query1->execute();
$results1=$query1->fetchAll(PDO::FETCH_OBJ);
$totreadqueries=$query1->rowCount();
?>
                                    <div class="text-left col-xs-3 mar-bot-15">
                                        <label class="label bg-green"></label>
                                    </div>
                                    <div class="col-xs-9 cus-gh-hd-pro">
                                        <h2 class="text-right no-margin"><?php echo htmlentities($totreadqueries);?></h2>
                                    </div>
                                </div>
                                <div class="progress progress-mini">
                                    <div style="width: 8%;" class="progress-bar progress-bar-danger bg-green"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="content-top-1 box3d">
                                <h4 class="text-left text-uppercase" style="color: magenta"><a href="unread-enquiry.php"><b>Unread Enquries</b></a></h4>
                                <div class="row vertical-center-box vertical-center-box-tablet">
                                	<?php 
						$sql1 ="SELECT * from  tblcontact where Isread is null";
$query1 = $dbh -> prepare($sql1);
$query1->execute();
$results1=$query1->fetchAll(PDO::FETCH_OBJ);
$totunreadqueries=$query1->rowCount();
?>
                                    <div class="text-left col-xs-3 mar-bot-15">
                                        <label class="label bg-blue"></label>
                                    </div>
                                    <div class="col-xs-9 cus-gh-hd-pro">
                                        <h2 class="text-right no-margin"><?php echo htmlentities($totunreadqueries);?></h2>
                                    </div>
                                </div>
                                <div class="progress progress-mini">
                                    <div style="width: 6%;" class="progress-bar bg-blue"></div>
                                </div>
                            </div>
                        </div>
                       
                    </div>
                </div>
						<div class="clearfix"></div>

						
					<div class="content-top">
								
		
		<?php include_once('includes/footer.php');?>
			</div>
			<!--content-->
		</div>
		
</div>
				<!--//content-inner-->
			
			<?php include_once('includes/sidebar.php');?>
							  <div class="clearfix"></div>		
							</div>
							<script>
							var toggle = true;
										
							$(".sidebar-icon").click(function() {                
							  if (toggle)
							  {
								$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
								$("#menu span").css({"position":"absolute"});
							  }
							  else
							  {
								$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
								setTimeout(function() {
								  $("#menu span").css({"position":"relative"});
								}, 400);
							  }
											
											toggle = !toggle;
										});
							</script>
<!--js -->
<script src="js/jquery.nicescroll.js"></script>
<script src="js/scripts.js"></script>
<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.min.js"></script>
   <!-- /Bootstrap Core JavaScript -->
   <!-- real-time -->
<script language="javascript" type="text/javascript" src="js/jquery.flot.js"></script>
	<script type="text/javascript">

	$(function() {

		var data = [],
			totalPoints = 300;

		function getRandomData() {

			if (data.length > 0)
				data = data.slice(1);

			// Do a random walk

			while (data.length < totalPoints) {

				var prev = data.length > 0 ? data[data.length - 1] : 50,
					y = prev + Math.random() * 10 - 5;

				if (y < 0) {
					y = 0;
				} else if (y > 100) {
					y = 100;
				}

				data.push(y);
			}

			// Zip the generated y values with the x values

			var res = [];
			for (var i = 0; i < data.length; ++i) {
				res.push([i, data[i]])
			}

			return res;
		}

		// Set up the control widget

		var updateInterval = 30;
		$("#updateInterval").val(updateInterval).change(function () {
			var v = $(this).val();
			if (v && !isNaN(+v)) {
				updateInterval = +v;
				if (updateInterval < 1) {
					updateInterval = 1;
				} else if (updateInterval > 2000) {
					updateInterval = 2000;
				}
				$(this).val("" + updateInterval);
			}
		});

		var plot = $.plot("#placeholder", [ getRandomData() ], {
			series: {
				shadowSize: 0	// Drawing is faster without shadows
			},
			yaxis: {
				min: 0,
				max: 100
			},
			xaxis: {
				show: false
			}
		});

		function update() {

			plot.setData([getRandomData()]);

			// Since the axes don't change, we don't need to call plot.setupGrid()

			plot.draw();
			setTimeout(update, updateInterval);
		}

		update();

		// Add the Flot version string to the footer

		$("#footer").prepend("Flot " + $.plot.version + " &ndash; ");
	});

	</script>

		   <script src="js/menu_jquery.js"></script>
</body>
</html><?php }  ?>